import React from "react";
import InventorySystem from "./InventorySystem";
import { Routes, Route, BrowserRouter } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<InventorySystem />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

