import React, { useState } from "react";
import '../index.css';

const ProductCard = ({ product, onIncrease, onDecrease, onEdit, onDelete }) => {
  const [editing, setEditing] = useState(false);
  const [editedName, setEditedName] = useState(product.name);
  const [editedImage, setEditedImage] = useState(product.image);

  const handleSave = () => {
    const updatedProduct = {
      ...product,
      name: editedName,
      image: editedImage
    };

    onEdit(updatedProduct);
    setEditing(false);
  };

  return (
    <div className="product-card">
      {editing ? (
        <>
          <input
            type="text"
            value={editedName}
            onChange={(e) => setEditedName(e.target.value)}
          />
          <input
            type="file"
            value={editedImage}
            onChange={(e) => setEditedImage(e.target.value)}
          />
          
          <button onClick={handleSave}>Save</button>
        </>
      ) : (
        <>
          <h3>{product.name}</h3>
          <img src={product.image} alt={product.name} width="100" />
          <p>Quantity: {product.quantity}</p>
          <button onClick={onIncrease}>Increase</button>
          <button onClick={onDecrease}>Decrease</button>
          <button className='none' onClick={() => setEditing(true)}>Edit</button>
          <button className='none' onClick={onDelete}>Delete</button>
        </>
      )}
    </div>
  );
};

export default ProductCard;
