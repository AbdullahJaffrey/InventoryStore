import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import ProductCard from './components/ProductCard';
import './index.css';

function InventorySystem() {
  const [products, setProducts] = useState(() => {
    const storedProducts = localStorage.getItem("products");
    return storedProducts ? JSON.parse(storedProducts) : [];
  });

  const [productName, setProductName] = useState("");
  const [imageURL, setImageURL] = useState("");
  const [quantity, setQuantity] = useState("");

  useEffect(() => {
    localStorage.setItem("products", JSON.stringify(products));
  }, [products]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const newProduct = {
      name: productName,
      image: imageURL,
      quantity: Number(quantity)
    };

    setProducts([...products, newProduct]);

    setProductName("");
    setImageURL("");
    setQuantity("");
  };

  const handleIncrease = (product) => {
    const updatedProducts = products.map((p) => {
      if (p === product) {
        return {
          ...p,
          quantity: p.quantity + 1
        };
      }
      return p;
    });

    setProducts(updatedProducts);
  };

  const handleDecrease = (product) => {
    const updatedProducts = products.map((p) => {
      if (p === product && p.quantity > 0) {
        return {
          ...p,
          quantity: p.quantity - 1
        };
      }
      return p;
    });

    setProducts(updatedProducts);
  };

  const handleEdit = (index, updatedProduct) => {
    const updatedProducts = [...products];
    updatedProducts[index] = updatedProduct;
    setProducts(updatedProducts);
  };

  const handleDelete = (index) => {
    const updatedProducts = products.filter((product, i) => i !== index);
    setProducts(updatedProducts);
  };

  return (
    <div className="container">
      <h1>Inventory System</h1>

      <form onSubmit={handleSubmit}>
        <label>
          Product Name:
          <input
            type="text"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
          />
        </label>
        <br />
        <label>
          Image:
          <input
            type="file"
            value={imageURL}
            onChange={(e) => setImageURL(e.target.value)}
          />
        </label>
        <br />
        <label>
          Quantity:
          <input
            type="number"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
          />
        </label>
        <br />
        <button type="submit">Add Product</button>
      </form>
      <br />

      <Link to="/products" className='none'>View Products</Link>
      <br />
      {products.length === 0 && <p>Please add an item.</p>}

      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Image</th>
            <th>Quantity</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product, index) => (
            <tr key={index}>
              <td>{product.name}</td>
              <td>
                <img src={product.image} alt={product.name} width="50" />
              </td>
              <td>{product.quantity}</td>
              <td>
                <button onClick={() => handleDelete(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>All Products</h2>

      <Link to="/" className="none">
        Go Back
      </Link>

      <div className="product-cards">
        {products.map((product, index) => (
          <ProductCard
            key={index}
            product={product}
            onIncrease={() => handleIncrease(product)}
            onDecrease={() => handleDecrease(product)}
          />
        ))}
      </div>
    </div>
  );
}

export default InventorySystem;